﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JWT.Algorithms;
using JWT.Builder;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AuthenticationCenter.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet]
        [Route("CheckAuthorize")]
        // [Authorize] //Microsoft.AspNetCore.Authorization
        public IActionResult CheckAuthorize()
        {
            try
            {
                //获取claims
                var claims = base.HttpContext.AuthenticateAsync().Result.Principal.Claims.ToList();
                //获取请求的token
                var token = base.HttpContext.AuthenticateAsync().Result.Properties.Items.ToArray()[0].Value;
                Console.WriteLine();
                return new JsonResult(new
                {
                    Data = "已授权",
                    Type = "CheckAuthorize",
                    Claim = claims[0].Issuer
                });
                
            }
            catch (Exception ex)
            {
                return new JsonResult(new
                {
                    Data = "未授权",
                    Type = "CheckAuthorize",
                    Exception= ex.ToString()
                });
            }
        }

    }
}
