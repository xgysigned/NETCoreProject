﻿using Microsoft.EntityFrameworkCore;
using WebAPINSwagTest_20200701.Models;

namespace WebAPINSwagTest_20200701.Models
{
    public class TodoContext : DbContext
    {
        public TodoContext(DbContextOptions<TodoContext> options)
            : base(options)
        {
        }

        public DbSet<TodoItem> TodoItems { get; set; }
    }
}