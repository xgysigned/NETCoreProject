﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPINSwagTest_20200701.Models
{
    public class TodoItem
    {
        /// <summary>
        /// 这是id
        /// </summary>
        [Required]
        public long Id { get; set; }
        /// <summary>
        /// 这是用户名
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 这是标识
        /// </summary>
        public bool IsComplete { get; set; }
    }
}
